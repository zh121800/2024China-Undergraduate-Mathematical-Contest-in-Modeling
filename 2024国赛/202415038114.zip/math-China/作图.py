import matplotlib.pyplot as plt
from matplotlib import rcParams
plt.rcParams['font.sans-serif'] = ['SimHei']  # 指定默认字体为黑体
plt.rcParams['axes.unicode_minus'] = False  # 解决保存图像时负号'-'显示为方块的
# 示例数据
x = [2024,2025,2026,2027,2028,2029,2030]  # 横坐标数据
y = [2, 3, 5, 7, 11,13,15]  # 纵坐标数据

# 创建折线图
plt.figure(figsize=(8, 6))  # 设置图表大小
plt.plot(x, y, marker='o', linestyle='-', color='b', label='数据')  # 绘制折线图

# 添加标题和轴标签
plt.title('简单折线图', fontsize=14)
plt.xlabel('X轴', fontsize=12)
plt.ylabel('Y轴', fontsize=12)

# 添加网格和图例
plt.grid(True)
plt.legend()

# 显示图表
plt.tight_layout()
plt.show()
