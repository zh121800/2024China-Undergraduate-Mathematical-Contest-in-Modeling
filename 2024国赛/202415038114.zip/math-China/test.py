import numpy as np
import matplotlib.pyplot as plt

# 示例数据
years = [2024, 2025, 2026, 2027, 2028, 2029, 2030]

# 创建图表
plt.figure(figsize=(10, 6),facecolor='white')

# 调整柱子的宽度（默认是 0.8，这里调为 0.5）
bars = plt.bar(years, P, color='#1f77b4', edgecolor='white',alpha=0.7, width=0.5)

# 添加标签和标题
plt.xlabel('Year')
plt.ylabel('Profit per year (million)')
plt.title('Profit from 2024 to 2030')

# 在柱子上方添加数据标签
# for bar in bars:
#     yval = bar.get_height()
#     plt.text(bar.get_x() + bar.get_width()/2, yval, round(yval, 1), ha='center', va='bottom', fontsize=10)

# 添加细网格
plt.grid(axis='y', linestyle='--', alpha=0.6)

# 显示图表
plt.tight_layout()
plt.show()
