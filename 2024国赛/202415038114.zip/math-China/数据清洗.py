import pandas as pd
file_path_1 = r'/home/maxdmx/math-China/附件2(1).xlsx'
file_path_2 = r'/home/maxdmx/math-China/附件2(2).xlsx'
# 读取 Excel 文件
df1 = pd.read_excel(file_path_1)
df2 = pd.read_excel(file_path_2)

# 去除每个单元格中的空格符
df1 = df1.applymap(lambda x: x.strip() if isinstance(x, str) else x)
df2 = df2.applymap(lambda x: x.strip() if isinstance(x, str) else x)

# 将修改后的 DataFrame 保存回 Excel 文件
df1.to_excel('/home/maxdmx/math-China/附件2(1)1.xlsx', index=False)
df2.to_excel('/home/maxdmx/math-China/附件2(2)1.xlsx', index=False)

print("已成功删除每个格子内容的空格符。")
